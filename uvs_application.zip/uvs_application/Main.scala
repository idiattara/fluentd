package uvs_application

import org.apache.spark.sql.SparkSession

object Main  extends App  {
  val path="src\\main\\scala\\uvs_application\\data.txt"
  val service=Services(path)
  implicit val spark: SparkSession = SparkSession.builder().appName("uvs")
    .master("local[*]").getOrCreate()
  val res=service.readData().count()
  println(s"le resul est  $res")



}
