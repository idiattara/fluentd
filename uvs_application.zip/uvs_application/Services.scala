package uvs_application
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

case class Services(path:String ) {

  def readData () (implicit spark: SparkSession) :RDD[String]=spark.sparkContext.textFile(path)

}


